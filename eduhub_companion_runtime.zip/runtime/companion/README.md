# EduHub Smart Companion 2.0 — Asset Pack

All character art is transparent PNG on one shared canvas (1736 x 2172), so every file lines up when stacked.

## Folders
- masters/      Full character, one per expression (neutral, closed, relaxed, curious, focus, thinking, attentive, delighted, surprised)
- character/    body_base.png + drop-in face overlays (eyes_*, eyebrows_*, mouth_*). Stack an overlay on body_base at 0,0 to switch expression without redrawing the face.
- portal/       portal_idle.svg, portal_active.svg (scalable home), portal_depth.png, portal_glow.png, portal_shadow.png
- effects/      emergence_glow, reaction_glow, soft_halo, soft_spark, light_particles (all transparent, restrained)
- references/   14 state references (01_idle ... 14_video_complete) + _contact_sheet.png. These are visual targets, not runtime assets.
- sequence/     Idle > Detect > Emerge > Focus > React > Retreat > Idle key poses + overview strip.

## Suggested runtime recipe (per state: expression, scale, rise, portal glow)
01 idle closed 0.85/0/0 · 02 wake neutral 0.9/0/0.4 · 03 listening relaxed 0.9/0/0.5 · 04 detecting curious 0.95/0/0.6
05 focus focus 1.15/0.18/0.8 · 06 thinking thinking 1.0/0.05/0.6 · 07 recognition attentive 1.1/0.12/0.8 · 08 delight delighted 1.1/0.12/0.8
09 surprise surprised 1.15/0.18/0.9 · 10 hero delighted 1.35/0.32/1.0 · 11 retreat relaxed 0.95/0.02/0.3 · 12 pause closed 0.85/0/0.15
13 speaker change curious 1.0/0.06/0.6 · 14 complete delighted 1.0/0.06/0.7
(rise = fraction of portal diameter the character lifts out; while rise is 0 clip the character to the portal circle.)

Palette: near-black #0E0C0A, charcoal #1A1714, gold #E8B050, amber #B8862F, hoodie green, dark brown hair.
